Dear User,

The software and the setup program are ONLY for  
Windows 7, Windows8 and Window 10.
The program t32m08.exe will not run on Windows 3.X, Windows95,
Windows98, Windows NT 4.0, Windows 2000, Windows XP, Windows Vista !

RTOS and Case Tool support files are not included in the demo package.

The HELP command (or button) provides access to the online manuals.
The manual is reduced version of the full online manual.
The "Simulator Tutorial" chapter helps to make the first steps.

For updates and new versions of this debugger please check in 

http://www.lauterbach.com.


Best Regards

The Lauterbach Team
